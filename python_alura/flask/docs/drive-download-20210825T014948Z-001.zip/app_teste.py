from flask import Flask, render_template

app = Flask(__name__)

class servicos:
    def __init__(self, codigo, tpserv):
        self.codigo = codigo
        self.tpserv = tpserv

@app.route('/')

def principal():
    serv1 = servicos('MAT215', 'Manuteção de micro')
    serv2 = servicos('WEB547', 'Desenvolvimento de Site')
    serv3 = servicos('RED987', 'Cabeamento Estruturado')
    lista = [serv1, serv2, serv3]
    titulo_do_site = "Veja os nossos Serviços1"
    return render_template('home.html',titulo=titulo_do_site, tipo_servicos = lista)

app.run()
